﻿using BE_GestionPropuestas.Repositorio;
using Microsoft.AspNetCore.Mvc;

namespace ApiGestionRespuestas.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PropuestaController : Controller
    {
        private readonly IRepositorioPropuestas _repositorioPropuesta;
        public PropuestaController(IRepositorioPropuestas propuesta)
        {
            this._repositorioPropuesta = propuesta;
        }
        [HttpGet]
        public async Task<IActionResult> Get()
        {
            try
            {
                var lista = await _repositorioPropuesta.ObtenerPropuestas();
                return Ok(lista);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
    }

}
