﻿using BE_GestionPropuestas.Repositorio;
using Microsoft.AspNetCore.Mvc;

namespace ApiGestionRespuestas.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class RevisionPropuestaController : Controller
    {
        private readonly IRepositorioRevisorPropuestas _repositorioPropuesta;
        public RevisionPropuestaController(IRepositorioRevisorPropuestas propuesta)
        {
            this._repositorioPropuesta = propuesta;
        }
        [HttpGet]
        public async Task<IActionResult> Get()
        {
            try
            {
                var lista = await _repositorioPropuesta.ObtenerRevisor();
                return Ok(lista);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
    }
}
