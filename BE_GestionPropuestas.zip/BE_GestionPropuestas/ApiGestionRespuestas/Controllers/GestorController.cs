﻿using BE_GestionPropuestas.Repositorio;
using Microsoft.AspNetCore.Mvc;

namespace ApiGestionRespuestas.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class GestorController : Controller
    {

        private readonly IRepositorioGestor _repositorioGestor;
        public GestorController(IRepositorioGestor gestor)
        {
            this._repositorioGestor = gestor;
        }
        [HttpGet]
        public async Task<IActionResult> Get()
        {
            try
            {
                var lista = await _repositorioGestor.ObtenerGestor();
                return Ok(lista);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
    }
}
