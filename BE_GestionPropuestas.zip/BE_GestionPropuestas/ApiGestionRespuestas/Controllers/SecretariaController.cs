﻿using BE_GestionPropuestas.Repositorio;
using Microsoft.AspNetCore.Mvc;

namespace ApiGestionRespuestas.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class SecretariaController : Controller
    {
        private readonly IRepositorioSecretaria _repositorioSecretaria;
        public SecretariaController(IRepositorioSecretaria secretaria)
        {
            this._repositorioSecretaria = secretaria;
        }
        [HttpGet]
        public async Task<IActionResult> Get()
        {
            try
            {
                var lista = await _repositorioSecretaria.ObtenerSecretaria();
                return Ok(lista);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
    }
}
