﻿using BE_GestionPropuestas.Repositorio;
using Microsoft.AspNetCore.Mvc;

namespace ApiGestionRespuestas.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AlumnoController : Controller
    {
        private readonly IRepositorioAlumno _repositorioAlumno;
        public AlumnoController(IRepositorioAlumno alumno)
        {
            this._repositorioAlumno = alumno;
        }
        [HttpGet]
        public async Task<IActionResult> Get()
        {
            try
            {
                var lista = await _repositorioAlumno.ObtenerAlumno();
                return Ok(lista);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
    }
}
