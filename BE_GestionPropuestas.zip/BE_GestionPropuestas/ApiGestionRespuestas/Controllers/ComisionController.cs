﻿using BE_GestionPropuestas.Entidades;
using BE_GestionPropuestas.Repositorio;
using Microsoft.AspNetCore.Mvc;

namespace ApiGestionRespuestas.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ComisionController : Controller
    {
        private readonly IRepositorioComisionRevision _repositorioComision;
        public ComisionController(IRepositorioComisionRevision comision)
        {
            this._repositorioComision = comision;
        }
        [HttpPost]
        public async Task<IActionResult> Post(ComisionRevision comision)
        {
            try
            {
                await _repositorioComision.Agregar(comision);
                return CreatedAtAction("Get", new { id = comision.ComisionRevisionId }, comision);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpGet("{id}")]
        public async Task<IActionResult> Get(int id)
        {
            var planificacion = await _repositorioComision.ObtenerPorId(id);
            if (planificacion == null)
            {
                return NotFound();
            }
            return Ok(planificacion);
        }
        [HttpGet]
        public async Task<IActionResult> Get()
        {
            try
            {
                var lista = await _repositorioComision.ObtenerPlanificacion();
                return Ok(lista);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

    }
}
