﻿using BE_GestionPropuestas.Entidades;
using BE_GestionPropuestas.Repositorio;
using Microsoft.AspNetCore.Mvc;

namespace ApiGestionRespuestas.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PlanificacionPeriodoController : Controller
    {
        private readonly IRepositorioPlanificacion _repositorioPlanificacionPeriodo;
        public PlanificacionPeriodoController(IRepositorioPlanificacion planificacionPeriodo)
        {
            this._repositorioPlanificacionPeriodo = planificacionPeriodo;
        }
            [HttpPost]
            public async Task<IActionResult> Post(Planificacion planificacionPeriodo)
            {
                try
                {
                    await _repositorioPlanificacionPeriodo.Agregar(planificacionPeriodo);
                    return CreatedAtAction("Get", new { id = planificacionPeriodo.PlanificacionId }, planificacionPeriodo);
                }
                catch (Exception ex)
                {
                    return BadRequest(ex.Message);
                }
            }
        [HttpGet("{id}")]
        public async Task<IActionResult> Get(int id)
        {
            var planificacion = await _repositorioPlanificacionPeriodo.ObtenerPorId(id);
            if (planificacion == null)
            {
                return NotFound();
            }
            return Ok(planificacion);
        }

        [HttpGet]
        public async Task<IActionResult> Get()
        {
            try
            {
                var lista = await _repositorioPlanificacionPeriodo.ObtenerPlanificacion();
                return Ok(lista);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

    }
}

