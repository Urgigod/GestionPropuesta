﻿using BE_GestionPropuestas.Entidades;
using BE_GestionPropuestas.Repositorio;
using Microsoft.AspNetCore.Mvc;

namespace ApiGestionRespuestas.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class InformeController : Controller
    {
        private readonly IRepositorioInformesRevision _repositorioAsignacion;
        public InformeController(IRepositorioInformesRevision asignacion)
        {
            this._repositorioAsignacion = asignacion;
        }
        [HttpPost]
        public async Task<IActionResult> Post(InformesRevision asignacion)
        {
            try
            {
                await _repositorioAsignacion.Agregar(asignacion);
                return CreatedAtAction("Get", new { id = asignacion.InformesRevisionId }, asignacion);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpGet("{id}")]
        public async Task<IActionResult> Get(int id)
        {
            var planificacion = await _repositorioAsignacion.ObtenerPorId(id);
            if (planificacion == null)
            {
                return NotFound();
            }
            return Ok(planificacion);
        }
        [HttpGet]
        public async Task<IActionResult> Get()
        {
            try
            {
                var lista = await _repositorioAsignacion.ObtenerPlanificacion();
                return Ok(lista);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
    }
}

