using BE_GestionPropuestas.Entidades;
using BE_GestionPropuestas.Repositorio;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);
// Add services to the container.
builder.Services.AddCors(options => options.AddPolicy("AllowWebApp",
                                builder => builder.AllowAnyOrigin()
                                .AllowAnyHeader()
                                .AllowAnyMethod()));
builder.Services.AddControllers().AddJsonOptions(opts =>
{
    opts.JsonSerializerOptions.ReferenceHandler = System.Text.Json.Serialization.ReferenceHandler.Preserve;
});
builder.Services.AddControllersWithViews();
// Agrega la conexion de la BD
builder.Services.AddDbContext<Conexion>(opciones =>
    opciones.UseSqlServer("name=DefaultConnection"));

builder.Services.AddControllers();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

builder.Services.AddScoped<IRepositorioPlanificacion, RepositorioPlanificacion>();
builder.Services.AddScoped<IRepositorioSecretaria, RepositorioSecretaria>();
builder.Services.AddScoped<IRepositorioGestor, RepositorioGestor>();
builder.Services.AddScoped<IRepositorioComisionRevision, RepositorioComisionRevision>();
builder.Services.AddScoped<IRepositorioAsignacionPropuestas, RepositorioAsignacionPropuestas>();
builder.Services.AddScoped<IRepositorioPropuestas, RepositorioPropuestas>();
builder.Services.AddScoped<IRepositorioRevisorPropuestas, RepositorioRevisorPropuestas>();
builder.Services.AddScoped<IRepositorioInformesRevision, RepositorioInformesRevision>();
builder.Services.AddScoped<IRepositorioRevisiones, RepositorioRevisiones>();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseCors("AllowWebApp");

app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.Run();
