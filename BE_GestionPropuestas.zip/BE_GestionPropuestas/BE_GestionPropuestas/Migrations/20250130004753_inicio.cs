﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace BE_GestionPropuestas.Migrations
{
    /// <inheritdoc />
    public partial class inicio : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Alumno",
                columns: table => new
                {
                    AlumnoId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    nombre = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Alumno", x => x.AlumnoId);
                });

            migrationBuilder.CreateTable(
                name: "Gestores",
                columns: table => new
                {
                    GestorId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    nombre = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Gestores", x => x.GestorId);
                });

            migrationBuilder.CreateTable(
                name: "RevisorPropuestas",
                columns: table => new
                {
                    RevisorPropuestasId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    nombre = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_RevisorPropuestas", x => x.RevisorPropuestasId);
                });

            migrationBuilder.CreateTable(
                name: "Secretarias",
                columns: table => new
                {
                    SecretariaId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    nombre = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Secretarias", x => x.SecretariaId);
                });

            migrationBuilder.CreateTable(
                name: "Propuestas",
                columns: table => new
                {
                    PropuestasId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    alumnoId = table.Column<int>(type: "int", nullable: false),
                    estado = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    fechaRegistro = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Propuestas", x => x.PropuestasId);
                    table.ForeignKey(
                        name: "FK_Propuestas_Alumno_alumnoId",
                        column: x => x.alumnoId,
                        principalTable: "Alumno",
                        principalColumn: "AlumnoId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "ComisionRevisiones",
                columns: table => new
                {
                    ComisionRevisionId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    gestorId = table.Column<int>(type: "int", nullable: false),
                    fechaCreacion = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ComisionRevisiones", x => x.ComisionRevisionId);
                    table.ForeignKey(
                        name: "FK_ComisionRevisiones_Gestores_gestorId",
                        column: x => x.gestorId,
                        principalTable: "Gestores",
                        principalColumn: "GestorId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Planificaciones",
                columns: table => new
                {
                    PlanificacionId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    secretariaId = table.Column<int>(type: "int", nullable: false),
                    fechaInicio = table.Column<DateTime>(type: "datetime2", nullable: false),
                    fechaFin = table.Column<DateTime>(type: "datetime2", nullable: false),
                    estado = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Planificaciones", x => x.PlanificacionId);
                    table.ForeignKey(
                        name: "FK_Planificaciones_Secretarias_secretariaId",
                        column: x => x.secretariaId,
                        principalTable: "Secretarias",
                        principalColumn: "SecretariaId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "AsignacionPropuestas",
                columns: table => new
                {
                    AsignacionPropuestasId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    propuestasId = table.Column<int>(type: "int", nullable: false),
                    revisorPropuestasID = table.Column<int>(type: "int", nullable: false),
                    fechaAsignacion = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AsignacionPropuestas", x => x.AsignacionPropuestasId);
                    table.ForeignKey(
                        name: "FK_AsignacionPropuestas_Propuestas_propuestasId",
                        column: x => x.propuestasId,
                        principalTable: "Propuestas",
                        principalColumn: "PropuestasId",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_AsignacionPropuestas_RevisorPropuestas_revisorPropuestasID",
                        column: x => x.revisorPropuestasID,
                        principalTable: "RevisorPropuestas",
                        principalColumn: "RevisorPropuestasId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "InformesRevisiones",
                columns: table => new
                {
                    InformesRevisionId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    propuestasId = table.Column<int>(type: "int", nullable: false),
                    gestorId = table.Column<int>(type: "int", nullable: false),
                    fechaGeneracion = table.Column<DateTime>(type: "datetime2", nullable: false),
                    observaciones = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_InformesRevisiones", x => x.InformesRevisionId);
                    table.ForeignKey(
                        name: "FK_InformesRevisiones_Gestores_gestorId",
                        column: x => x.gestorId,
                        principalTable: "Gestores",
                        principalColumn: "GestorId",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_InformesRevisiones_Propuestas_propuestasId",
                        column: x => x.propuestasId,
                        principalTable: "Propuestas",
                        principalColumn: "PropuestasId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Revisiones",
                columns: table => new
                {
                    RevisionesId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    propuestasId = table.Column<int>(type: "int", nullable: false),
                    revisorPropuestasId = table.Column<int>(type: "int", nullable: false),
                    fechaRevision = table.Column<DateTime>(type: "datetime2", nullable: false),
                    viabilidad = table.Column<bool>(type: "bit", nullable: false),
                    necesitaCorrecciones = table.Column<bool>(type: "bit", nullable: false),
                    observaciones = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Revisiones", x => x.RevisionesId);
                    table.ForeignKey(
                        name: "FK_Revisiones_Propuestas_propuestasId",
                        column: x => x.propuestasId,
                        principalTable: "Propuestas",
                        principalColumn: "PropuestasId",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_Revisiones_RevisorPropuestas_revisorPropuestasId",
                        column: x => x.revisorPropuestasId,
                        principalTable: "RevisorPropuestas",
                        principalColumn: "RevisorPropuestasId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_AsignacionPropuestas_propuestasId",
                table: "AsignacionPropuestas",
                column: "propuestasId");

            migrationBuilder.CreateIndex(
                name: "IX_AsignacionPropuestas_revisorPropuestasID",
                table: "AsignacionPropuestas",
                column: "revisorPropuestasID");

            migrationBuilder.CreateIndex(
                name: "IX_ComisionRevisiones_gestorId",
                table: "ComisionRevisiones",
                column: "gestorId");

            migrationBuilder.CreateIndex(
                name: "IX_InformesRevisiones_gestorId",
                table: "InformesRevisiones",
                column: "gestorId");

            migrationBuilder.CreateIndex(
                name: "IX_InformesRevisiones_propuestasId",
                table: "InformesRevisiones",
                column: "propuestasId");

            migrationBuilder.CreateIndex(
                name: "IX_Planificaciones_secretariaId",
                table: "Planificaciones",
                column: "secretariaId");

            migrationBuilder.CreateIndex(
                name: "IX_Propuestas_alumnoId",
                table: "Propuestas",
                column: "alumnoId");

            migrationBuilder.CreateIndex(
                name: "IX_Revisiones_propuestasId",
                table: "Revisiones",
                column: "propuestasId");

            migrationBuilder.CreateIndex(
                name: "IX_Revisiones_revisorPropuestasId",
                table: "Revisiones",
                column: "revisorPropuestasId");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "AsignacionPropuestas");

            migrationBuilder.DropTable(
                name: "ComisionRevisiones");

            migrationBuilder.DropTable(
                name: "InformesRevisiones");

            migrationBuilder.DropTable(
                name: "Planificaciones");

            migrationBuilder.DropTable(
                name: "Revisiones");

            migrationBuilder.DropTable(
                name: "Gestores");

            migrationBuilder.DropTable(
                name: "Secretarias");

            migrationBuilder.DropTable(
                name: "Propuestas");

            migrationBuilder.DropTable(
                name: "RevisorPropuestas");

            migrationBuilder.DropTable(
                name: "Alumno");
        }
    }
}
