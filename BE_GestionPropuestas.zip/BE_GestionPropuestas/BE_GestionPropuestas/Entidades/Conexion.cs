﻿using Microsoft.EntityFrameworkCore;

namespace BE_GestionPropuestas.Entidades
{
    public class Conexion : DbContext
    {
        public Conexion(DbContextOptions options) : base(options) { }
        //******SE EJECUTA PRIMERO PARA HACER LAS MIGRACIONES******
       /* protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer(@"Server=MISHA;Database=GestionPropuestas;Integrated Security=True;TrustServerCertificate=True;");
        }*/
        public DbSet<Alumno> Alumno { get; set; }
        public DbSet<AsignacionPropuestas> AsignacionPropuestas { get; set; }
        public DbSet<ComisionRevision> ComisionRevisiones { get; set; }
        public DbSet<Gestor> Gestores { get; set; }
        public DbSet<InformesRevision> InformesRevisiones { get; set; }
        public DbSet<Planificacion> Planificaciones { get; set; }
        public DbSet<Propuestas> Propuestas { get; set; }
        public DbSet<Revisiones> Revisiones { get; set; }
        public DbSet<RevisorPropuestas> RevisorPropuestas { get; set; }
        public DbSet<Secretaria> Secretarias { get; set; }
    }
}
