﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BE_GestionPropuestas.Entidades
{
    public class Propuestas
    {
        public int PropuestasId { get; set; }
        public int alumnoId { get; set; }
        public string estado { get; set; } = string.Empty;
        public DateTime fechaRegistro { get; set; }

        public Alumno? alumno { get; set; }
    }
}
