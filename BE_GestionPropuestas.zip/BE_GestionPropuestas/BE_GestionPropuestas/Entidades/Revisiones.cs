﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BE_GestionPropuestas.Entidades
{
    public class Revisiones
    {
        public int RevisionesId { get; set; }
        public int propuestasId { get; set; }
        public int revisorPropuestasId { get; set; }
        public DateTime fechaRevision { get; set; }
        public bool viabilidad { get; set; }
        public bool necesitaCorrecciones { get; set; }
        public string observaciones { get; set; } = string.Empty;

        public Propuestas? propuestas { get; set; }
        public RevisorPropuestas? revisorPropuestas { get; set; }
    }
}
