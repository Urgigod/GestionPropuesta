﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BE_GestionPropuestas.Entidades
{
    public class InformesRevision
    {
        public int InformesRevisionId { get; set; }
        public int propuestasId { get; set; }
        public int gestorId { get; set; }
        public DateTime fechaGeneracion { get; set; }
        public string observaciones { get; set; } = string.Empty;
        public Propuestas? propuestas { get; set; }
        public Gestor? gestor { get; set; }
    }
}
