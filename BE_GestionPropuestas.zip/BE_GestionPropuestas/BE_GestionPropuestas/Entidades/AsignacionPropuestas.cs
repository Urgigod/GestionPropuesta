﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BE_GestionPropuestas.Entidades
{
    public class AsignacionPropuestas
    {

        public int AsignacionPropuestasId { get; set; }
        public int propuestasId { get; set; }
        public int revisorPropuestasID { get; set; }

        public DateTime fechaAsignacion { get; set; }

        public Propuestas? propuestas { get; set; }
        public RevisorPropuestas? revisorPropuestas { get; set; }
     
    }
}
