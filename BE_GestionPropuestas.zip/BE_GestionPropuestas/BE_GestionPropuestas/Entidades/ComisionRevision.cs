﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BE_GestionPropuestas.Entidades
{
    public class ComisionRevision
    {
        public int ComisionRevisionId { get; set; }
        public int gestorId { get; set; }

        public DateTime fechaCreacion { get; set; }

        public Gestor? gestor { get; set; }
    }
}
