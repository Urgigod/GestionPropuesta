﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BE_GestionPropuestas.Entidades
{
    public class Gestor
    {
        public int GestorId { get; set; }
        public string nombre { get; set; } = string.Empty;
    }
}
