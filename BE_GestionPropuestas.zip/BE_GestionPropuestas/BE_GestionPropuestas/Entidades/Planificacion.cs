﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BE_GestionPropuestas.Entidades
{
    public class Planificacion
    {
        public int PlanificacionId { get; set; }
       
        public int secretariaId { get; set; }

        public DateTime fechaInicio { get; set; }

        public DateTime fechaFin { get; set; }
        public string estado { get; set; } = string.Empty;
        
        public Secretaria? secretaria { get; set; }
    }
}
