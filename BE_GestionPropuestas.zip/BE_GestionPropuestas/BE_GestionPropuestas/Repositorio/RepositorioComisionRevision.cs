﻿using BE_GestionPropuestas.Entidades;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BE_GestionPropuestas.Repositorio
{
    public class RepositorioComisionRevision : IRepositorioComisionRevision
    {
        private readonly Conexion context;

        public RepositorioComisionRevision(Conexion context)
        {
            this.context = context;
        }
        public async Task<int> Agregar(ComisionRevision comisionRevision)
        {
            context.ComisionRevisiones.Add(comisionRevision);
            await context.SaveChangesAsync();
            return comisionRevision.ComisionRevisionId;
        }

        public Task<List<ComisionRevision>> ObtenerPlanificacion()
        {
            return context.ComisionRevisiones
          .Include(libro => libro.gestor)
       
          .ToListAsync();
        }

        public async Task<ComisionRevision?> ObtenerPorId(int id)
        {
            return await context.ComisionRevisiones.FindAsync(id);
        }
    }
}
