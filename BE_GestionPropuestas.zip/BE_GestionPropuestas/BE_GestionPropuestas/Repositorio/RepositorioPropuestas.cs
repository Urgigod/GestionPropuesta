﻿using BE_GestionPropuestas.Entidades;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BE_GestionPropuestas.Repositorio
{
    public class RepositorioPropuestas : IRepositorioPropuestas
    {
        private readonly Conexion context;

        public RepositorioPropuestas(Conexion context)
        {
            this.context = context;
        }
        public  Task<List<Propuestas>> ObtenerPropuestas()
        {
           // return await context.Propuestas.ToListAsync();
            return context.Propuestas
           .Include(libro => libro.alumno)
           .ToListAsync();
        }
    }
}
