﻿using BE_GestionPropuestas.Entidades;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BE_GestionPropuestas.Repositorio
{
    public class RepositorioAsignacionPropuestas : IRepositorioAsignacionPropuestas
    {
        private readonly Conexion context;

        public RepositorioAsignacionPropuestas(Conexion context)
        {
            this.context = context;
        }
        public async Task<int> Agregar(AsignacionPropuestas asignacionPropuestas)
        {
            context.AsignacionPropuestas.Add(asignacionPropuestas);
            await context.SaveChangesAsync();
            return asignacionPropuestas.AsignacionPropuestasId;
        }

        public async Task<AsignacionPropuestas?> ObtenerPorId(int id)
        {
            return await context.AsignacionPropuestas.FindAsync(id);
        }
        public Task<List<AsignacionPropuestas>> ObtenerPlanificacion()
        {
            // return await context.Propuestas.ToListAsync();
            return context.AsignacionPropuestas
           .Include(libro => libro.propuestas)
           .Include(libro => libro.revisorPropuestas)
           .ToListAsync();
        }
    }
}
