﻿using BE_GestionPropuestas.Entidades;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BE_GestionPropuestas.Repositorio
{
    public class RepositorioRevisiones : IRepositorioRevisiones
    {
        private readonly Conexion context;

        public RepositorioRevisiones(Conexion context)
        {
            this.context = context;
        }
        public async Task<int> Agregar(Revisiones reevisiones)
        {

            context.Revisiones.Add(reevisiones);
            await context.SaveChangesAsync();
            return reevisiones.RevisionesId;
        }

        public Task<List<Revisiones>> ObtenerPlanificacion()
        {
            return context.Revisiones
          .Include(libro => libro.propuestas)
          .Include(libro => libro.revisorPropuestas)
          .ToListAsync();
        }

        public async Task<Revisiones?> ObtenerPorId(int id)
        {
            return await context.Revisiones.FindAsync(id);
        }
    }
}
