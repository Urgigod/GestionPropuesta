﻿using BE_GestionPropuestas.Entidades;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BE_GestionPropuestas.Repositorio
{

    public class RepositorioAlumno : IRepositorioAlumno
    {
        private readonly Conexion context;

        public RepositorioAlumno(Conexion context)
        {
            this.context = context;
        }
        public async Task<List<Alumno>> ObtenerAlumno()
        {
            return await context.Alumno.ToListAsync();
        }

    
    }
}
