﻿using BE_GestionPropuestas.Entidades;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BE_GestionPropuestas.Repositorio
{
    public class RepositorioRevisorPropuestas : IRepositorioRevisorPropuestas
    {
        private readonly Conexion context;

        public RepositorioRevisorPropuestas(Conexion context)
        {
            this.context = context;
        }

        public  Task<List<RevisorPropuestas>> ObtenerRevisor()
        {
            //return await context.RevisorPropuestas.ToListAsync();
            return context.RevisorPropuestas
          .Include(libro => libro.nombre)
          .ToListAsync();
        }
    }
}
