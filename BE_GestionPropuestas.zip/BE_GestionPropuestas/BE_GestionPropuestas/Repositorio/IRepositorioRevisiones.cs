﻿using BE_GestionPropuestas.Entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BE_GestionPropuestas.Repositorio
{
    public interface IRepositorioRevisiones
    {
        Task<int> Agregar(Revisiones reevisiones);
        Task<Revisiones?> ObtenerPorId(int id);
        Task<List<Revisiones>> ObtenerPlanificacion();
    }
}
