﻿using BE_GestionPropuestas.Entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BE_GestionPropuestas.Repositorio
{
    public interface IRepositorioRevisorPropuestas
    {
        Task<List<RevisorPropuestas>> ObtenerRevisor();
    }
}
