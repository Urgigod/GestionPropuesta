﻿using BE_GestionPropuestas.Entidades;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BE_GestionPropuestas.Repositorio
{
    public class RepositorioInformesRevision : IRepositorioInformesRevision
    {
        private readonly Conexion context;

        public RepositorioInformesRevision(Conexion context)
        {
            this.context = context;
        }
        public async Task<int> Agregar(InformesRevision informe)
        {
            context.InformesRevisiones.Add(informe);
            await context.SaveChangesAsync();
            return informe.InformesRevisionId;
        }

        public Task<List<InformesRevision>> ObtenerPlanificacion()
        {
            return context.InformesRevisiones
           .Include(libro => libro.propuestas)
           .Include(libro => libro.gestor)
           .ToListAsync();
        }

        public async Task<InformesRevision?> ObtenerPorId(int id)
        {
            return await context.InformesRevisiones.FindAsync(id);
        }
    }
}
