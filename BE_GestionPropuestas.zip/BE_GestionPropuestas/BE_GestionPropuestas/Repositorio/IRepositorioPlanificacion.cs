﻿using BE_GestionPropuestas.Entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BE_GestionPropuestas.Repositorio
{
    public interface IRepositorioPlanificacion
    {
        Task<int> Agregar(Planificacion planificacionPeriodo);
        Task<Planificacion?> ObtenerPorId(int id);
        Task<List<Planificacion>> ObtenerPlanificacion();

    }
}
