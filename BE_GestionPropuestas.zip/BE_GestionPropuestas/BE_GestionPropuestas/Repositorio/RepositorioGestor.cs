﻿using BE_GestionPropuestas.Entidades;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BE_GestionPropuestas.Repositorio
{
    public class RepositorioGestor : IRepositorioGestor
    {
        private readonly Conexion context;

        public RepositorioGestor(Conexion context)
        {
            this.context = context;
        }
        public async Task<List<Gestor>> ObtenerGestor()
        {
            return await context.Gestores.ToListAsync();
        }
    }
}
