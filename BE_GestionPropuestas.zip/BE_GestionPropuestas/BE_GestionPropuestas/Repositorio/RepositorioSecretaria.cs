﻿using BE_GestionPropuestas.Entidades;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BE_GestionPropuestas.Repositorio
{
    public class RepositorioSecretaria : IRepositorioSecretaria
    {
        private readonly Conexion context;

        public RepositorioSecretaria(Conexion context)
        {
            this.context = context;
        }
        public async Task<List<Secretaria>> ObtenerSecretaria()
        {
            return await context.Secretarias.ToListAsync();
        }
    }
}
