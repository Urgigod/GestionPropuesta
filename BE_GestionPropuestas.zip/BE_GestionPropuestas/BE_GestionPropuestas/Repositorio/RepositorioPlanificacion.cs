﻿using BE_GestionPropuestas.Entidades;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BE_GestionPropuestas.Repositorio
{
    public class RepositorioPlanificacion : IRepositorioPlanificacion
    {
        private readonly Conexion context;

        public RepositorioPlanificacion(Conexion context)
        {
            this.context = context;
        }
        public async Task<int> Agregar(Planificacion planificacionPeriodo)
        {
          
            context.Planificaciones.Add(planificacionPeriodo);
            await context.SaveChangesAsync();
            return planificacionPeriodo.PlanificacionId;
        }
        public async Task<Planificacion?> ObtenerPorId(int id)
        {
            return await context.Planificaciones.FindAsync(id);
        }
        public Task<List<Planificacion>> ObtenerPlanificacion()
        {
            // return await context.Propuestas.ToListAsync();
            return context.Planificaciones
           .Include(libro => libro.secretaria)
           .ToListAsync();
        }

    }
}
