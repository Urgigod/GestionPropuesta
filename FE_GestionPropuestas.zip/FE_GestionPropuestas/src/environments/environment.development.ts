export const environment = {
    production: false,
     endpoint: "https://localhost:7023/"
};
