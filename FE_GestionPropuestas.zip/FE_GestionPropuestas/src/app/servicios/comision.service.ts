import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment.development';
import { HttpClient } from '@angular/common/http';
import { map, Observable } from 'rxjs';
import { ComisionRevision } from '../componentes/interfaces/ComisionRevision';

@Injectable({
  providedIn: 'root'
})
export class ComisionService {

    private myAppUrl: string = environment.endpoint;
     private myApiUrl: string = 'api/Comision/';
   
     constructor(private http: HttpClient) { }
     addComision(planificacion: ComisionRevision): Observable<number> {
       return this.http.post<number>(`${this.myAppUrl}${this.myApiUrl}`, planificacion);
     }
            getGestor(): Observable<ComisionRevision[]> {
                       return this.http.get<any>(`${this.myAppUrl}${this.myApiUrl}`).pipe(
                         map(response => response.$values || []) // Extract the $values array
                       );
                     }
}
