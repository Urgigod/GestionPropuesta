import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment.development';
import { HttpClient } from '@angular/common/http';
import { InformesRevision } from '../componentes/interfaces/InformesRevision';
import { map, Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class InformeService {
   private myAppUrl: string = environment.endpoint;
      private myApiUrl: string = 'api/Informe/';
      constructor(private http: HttpClient) { }
      addComision(planificacion: InformesRevision): Observable<number> {
        return this.http.post<number>(`${this.myAppUrl}${this.myApiUrl}`, planificacion);
      }
           getGestor(): Observable<InformesRevision[]> {
           return this.http.get<any>(`${this.myAppUrl}${this.myApiUrl}`).pipe(
           map(response => response.$values || []) // Extract the $values array
           );
         }
}
