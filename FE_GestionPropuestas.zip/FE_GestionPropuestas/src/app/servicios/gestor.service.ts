import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment.development';
import { HttpClient } from '@angular/common/http';
import { map, Observable } from 'rxjs';
import { Gestor } from '../componentes/interfaces/Gestor';

@Injectable({
  providedIn: 'root'
})
export class GestorService {

      private myAppUrl: string = environment.endpoint;
        private myApiUrl: string = 'api/Gestor/';
      
        constructor(private http: HttpClient) { }
        getGestor(): Observable<Gestor[]> {
          return this.http.get<any>(`${this.myAppUrl}${this.myApiUrl}`).pipe(
            map(response => response.$values || []) // Extract the $values array
          );
        }
}
