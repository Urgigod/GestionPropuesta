import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment.development';
import { HttpClient } from '@angular/common/http';
import { map, Observable } from 'rxjs';
import { RevisorPropuestas } from '../componentes/interfaces/RevisorPropuestas';

@Injectable({
  providedIn: 'root'
})
export class RevisionService {

   private myAppUrl: string = environment.endpoint;
          private myApiUrl: string = 'api/RevisionPropuesta/';
        
          constructor(private http: HttpClient) { }
          getGestor(): Observable<RevisorPropuestas[]> {
            return this.http.get<any>(`${this.myAppUrl}${this.myApiUrl}`).pipe(
              map(response => response.$values || []) // Extract the $values array
            );
          }
}
