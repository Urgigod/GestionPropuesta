import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment.development';
import { HttpClient } from '@angular/common/http';
import { AsignacionPropuestas } from '../componentes/interfaces/AsignacionPropuestas';
import { map, Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AsignacionService {

   private myAppUrl: string = environment.endpoint;
      private myApiUrl: string = 'api/AsignacionPropuesta/';
    
      constructor(private http: HttpClient) { }
      addComision(planificacion: AsignacionPropuestas): Observable<number> {
        return this.http.post<number>(`${this.myAppUrl}${this.myApiUrl}`, planificacion);
      }
        getGestor(): Observable<AsignacionPropuestas[]> {
                             return this.http.get<any>(`${this.myAppUrl}${this.myApiUrl}`).pipe(
                               map(response => response.$values || []) // Extract the $values array
                             );
                           }
    }
