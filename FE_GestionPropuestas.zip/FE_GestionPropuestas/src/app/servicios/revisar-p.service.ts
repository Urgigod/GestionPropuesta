import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment.development';
import { HttpClient } from '@angular/common/http';
import { Revisiones } from '../componentes/interfaces/Revisiones';
import { map, Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class RevisarPService {

 private myAppUrl: string = environment.endpoint;
       private myApiUrl: string = 'api/Revisar/';
     
       constructor(private http: HttpClient) { }
       addComision(planificacion: Revisiones): Observable<number> {
         return this.http.post<number>(`${this.myAppUrl}${this.myApiUrl}`, planificacion);
       }
               getGestor(): Observable<Revisiones[]> {
                  return this.http.get<any>(`${this.myAppUrl}${this.myApiUrl}`).pipe(
                  map(response => response.$values || []) // Extract the $values array
                  );
                }
}
