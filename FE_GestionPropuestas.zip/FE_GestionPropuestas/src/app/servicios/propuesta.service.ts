import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, map } from 'rxjs';
import { environment } from '../../environments/environment.development';
import { RevisorPropuestas } from '../componentes/interfaces/RevisorPropuestas';
import { Propuestas } from '../componentes/interfaces/Propuestas';

@Injectable({
  providedIn: 'root'
})
export class PropuestaService {

     private myAppUrl: string = environment.endpoint;
            private myApiUrl: string = 'api/Propuesta/';
          
            constructor(private http: HttpClient) { }
            getGestor(): Observable<Propuestas[]> {
              return this.http.get<any>(`${this.myAppUrl}${this.myApiUrl}`).pipe(
                map(response => response.$values || []) // Extract the $values array
              );
            }
}
