import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment.development';
import { HttpClient } from '@angular/common/http';
import { PlanificacionPeriodo } from '../componentes/interfaces/PlanificacionPeriodo';
import { map, Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class PlanificacionService {

    private myAppUrl: string = environment.endpoint;
    private myApiUrl: string = 'api/PlanificacionPeriodo/';
  
    constructor(private http: HttpClient) { }
    addPlanificacion(planificacion: PlanificacionPeriodo): Observable<number> {
      return this.http.post<number>(`${this.myAppUrl}${this.myApiUrl}`, planificacion);
    }
       getGestor(): Observable<PlanificacionPeriodo[]> {
                  return this.http.get<any>(`${this.myAppUrl}${this.myApiUrl}`).pipe(
                    map(response => response.$values || []) // Extract the $values array
                  );
                }
}
