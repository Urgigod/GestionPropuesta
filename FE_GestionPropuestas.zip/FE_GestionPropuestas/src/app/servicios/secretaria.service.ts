import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment.development';
import { HttpClient } from '@angular/common/http';
import { map, Observable } from 'rxjs';
import { Secretaria } from '../componentes/interfaces/Secretaria';

@Injectable({
  providedIn: 'root'
})
export class SecretariaService {

    private myAppUrl: string = environment.endpoint;
      private myApiUrl: string = 'api/Secretaria/';
    
      constructor(private http: HttpClient) { }
      getSecretaria(): Observable<Secretaria[]> {
        return this.http.get<any>(`${this.myAppUrl}${this.myApiUrl}`).pipe(
          map(response => response.$values || []) // Extract the $values array
        );
      }
}
