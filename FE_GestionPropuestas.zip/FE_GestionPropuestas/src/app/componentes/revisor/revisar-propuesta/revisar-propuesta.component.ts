import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { Router, RouterModule } from '@angular/router';
import { Propuestas } from '../../interfaces/Propuestas';
import { RevisorPropuestas } from '../../interfaces/RevisorPropuestas';
import { PropuestaService } from '../../../servicios/propuesta.service';
import { RevisionService } from '../../../servicios/revision.service';
import { RevisarPService } from '../../../servicios/revisar-p.service';
import { Revisiones } from '../../interfaces/Revisiones';

@Component({
  selector: 'app-revisar-propuesta',
  standalone: true,
  imports: [ReactiveFormsModule, RouterModule, CommonModule],
  templateUrl: './revisar-propuesta.component.html',
  styleUrl: './revisar-propuesta.component.css'
})
export class RevisarPropuestaComponent {
form: FormGroup;
  listaPropuestas: Propuestas[] = [];
  listaRevisor: RevisorPropuestas[] = [];
  lista: Revisiones[] = [];

  constructor(private fb: FormBuilder, 
    private _propuestaService: PropuestaService,
    private _revisorService: RevisionService,
    private _revisorRService: RevisarPService,
    private router: Router
   
   ) {
    this.form = this.fb.group({
      revisorPropuestasId: ['', Validators.required],
      propuestasId: ['', Validators.required],
      observaciones: ['', Validators.required],
      fechaRevision: ['', Validators.required],
      viabilidad: ['', Validators.required],
      necesitaCorrecciones: ['', Validators.required],

    });
  }
  ngOnInit(): void {
    this.consultarPropuestas();
    this.consultarRevisores();
    this.obtenerR();
  }

  consultarPropuestas(): void {
    this._propuestaService.getGestor().subscribe({
      next: (data) => {
        this.listaPropuestas = data;
      },
      error: (error) => {
        console.error('Error fetching propuestas:', error);
      }
    });
  }

  consultarRevisores(): void {
    this._revisorService.getGestor().subscribe({
      next: (data) => {
        this.listaRevisor = data;
      },
      error: (error) => {
        console.error('Error fetching revisores:', error);
      }
    });
  }

  agregarPlanificacion() {
    console.log('Form Values:', this.form.value);
    const plan: Revisiones = {
      revisorPropuestasId: +this.form.value.revisorPropuestasId, // Convert to number
      propuestasId: +this.form.value.propuestasId, // Convert to number
      observaciones: this.form.value.observaciones,
      fechaRevision: this.form.value.fechaRevision, // Convert to ISO format
      viabilidad: this.form.value.viabilidad === 'true', // Convert string to boolean
      necesitaCorrecciones: this.form.value.necesitaCorrecciones === 'true', // Convert string to boolean
    };

    this._revisorRService.addComision(plan).subscribe({
      next: data => {
        console.log(data);
      },
      error: error => {
        console.error('Error:', error);
        alert("Ocurrió un error");
      },
      complete: () => {
        console.info('Agregar plan completa');
        alert("Se agrego correctamente");
      }
    });
    this.form.reset();
  }

  obtenerR(): void {
    this._revisorRService.getGestor().subscribe({
      next: data => {
        console.log(data);
        this.lista = data;
      },
      error: error => {
        alert("Ocurrió un error");
      },
      complete: () => {
        console.info('Obtención de propuesta completa');
      }
    });
  }
}
