import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RevisarPropuestaComponent } from './revisar-propuesta.component';

describe('RevisarPropuestaComponent', () => {
  let component: RevisarPropuestaComponent;
  let fixture: ComponentFixture<RevisarPropuestaComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [RevisarPropuestaComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(RevisarPropuestaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
