import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { Router, RouterModule } from '@angular/router';
import { Propuestas } from '../../interfaces/Propuestas';
import { RevisorPropuestas } from '../../interfaces/RevisorPropuestas';
import { PropuestaService } from '../../../servicios/propuesta.service';
import { RevisionService } from '../../../servicios/revision.service';
import { AsignacionService } from '../../../servicios/asignacion.service';
import { AsignacionPropuestas } from '../../interfaces/AsignacionPropuestas';
import { AlumnoService } from '../../../servicios/alumno.service';
import { Alumno } from '../../interfaces/alumno';
import { Gestor } from '../../interfaces/Gestor';
import { GestorService } from '../../../servicios/gestor.service';
import { InformesRevision } from '../../interfaces/InformesRevision';
import { InformeService } from '../../../servicios/informe.service';

@Component({
  selector: 'app-asignar-propuestas',
  standalone: true,
  imports: [ReactiveFormsModule, RouterModule, CommonModule],
  templateUrl: './asignar-propuestas.component.html',
  styleUrl: './asignar-propuestas.component.css'
})
export class AsignarPropuestasComponent {
 form: FormGroup;
 form2: FormGroup;
  listaPropuesta: Propuestas[] = [];
  listaRevisor: RevisorPropuestas[] = [];
  listaAlumnos: Alumno[] = [];
  listaGestor: Gestor[] = [];
  lista: AsignacionPropuestas[] = [];
  listaa: InformesRevision[] = [];

  constructor(private fb: FormBuilder, 
    private _propuestaService: PropuestaService,
    private _revisorService: RevisionService,
    private _asignacionService: AsignacionService,
    private _alumnoService: AlumnoService,
    private _GestorService: GestorService,
    private _informeService: InformeService,
    private router: Router
   
   ) {
    this.form = this.fb.group({
      propuestasId: ['', Validators.required],
      revisorPropuestasId: ['', Validators.required],
      fechaAsignacion: ['', Validators.required], 
    
    }),
    this.form2 = this.fb.group({
      propuestasId: ['', Validators.required],
      gestorId: ['', Validators.required],
      observaciones: ['', Validators.required],
      fechaGeneracion: ['', Validators.required], });
  }


  ngOnInit(): void {
    this.consultarPropuesta();
    this.consultarRevisor();
    this.consultarAlumno();
    this. consultarGestors();
    this. obtenerPropuesta();
    this. obtenerInforme();
  }

  consultarPropuesta(): void {
    this._propuestaService.getGestor().subscribe({
      next: (data) => {
        console.log('Fetched propuestas:', data);
        this.listaPropuesta = data;
        if (this.listaAlumnos.length > 0) {
          this.mapAlumnosToPropuestas();
        }
      },
      error: (error) => {
        console.error('Error fetching propuestas:', error);
      }
    });
  }
  consultarGestors(): void {
    this._GestorService.getGestor().subscribe({
      next: (data) => {
        console.log('Fetched secretarias:', data); // Log the data to verify it's an array
        this.listaGestor = data;
      },
      error: (error) => {
        console.error('Error fetching secretarias:', error);
      }
    });
  }

  consultarAlumno(): void {
    this._alumnoService.getGestor().subscribe({
      next: (data) => {
        console.log('Fetched alumnos:', data);
        this.listaAlumnos = data;
        if (this.listaPropuesta.length > 0) {
          this.mapAlumnosToPropuestas();
        }
      },
      error: (error) => {
        console.error('Error fetching alumnos:', error);
      }
    });
  }

    consultarRevisor(): void {
      this._revisorService.getGestor().subscribe({
        next: (data) => {
          console.log('Fetched secretarias:', data); // Log the data to verify it's an array
          this.listaRevisor = data;
        },
        error: (error) => {
          console.error('Error fetching secretarias:', error);
        }
      });
    }

  agregarPlanificacion(){
    const plan: AsignacionPropuestas = {

      propuestasId: this.form.value.propuestasId,
      revisorPropuestasId: this.form.value.revisorPropuestasId,
      fechaAsignacion: this.form.value.fechaAsignacion,
   
    }

    this._asignacionService.addComision(plan).subscribe({
      next: data => {
        console.log(data);
       
      },
      error: error => {
        alert("Ocurrió un error");
      },
      complete: () => {
        console.info('Agregar plan completa');
        alert("Se agrego correctamente");
      }
    });
    this.form.reset();
  }
  mapAlumnosToPropuestas(): void {
    if (this.listaPropuesta.length > 0 && this.listaAlumnos.length > 0) {
      this.listaPropuesta.forEach(propuesta => {
        propuesta.alumno = this.listaAlumnos.find(alumno => alumno.alumnoId === 
          +propuesta.alumnoId!); // Convert to number
        console.log('Mapped propuesta:', propuesta);
      });
    }
  }

  agregarInforme(){
    const plan: InformesRevision = {

      propuestasId: this.form2.value.propuestasId,
      gestorId: this.form2.value.gestorId,
      
      fechaGeneracion: this.form2.value.fechaGeneracion,
      observaciones: this.form2.value.observaciones,
   
    }

    this._informeService.addComision(plan).subscribe({
      next: data => {
        console.log(data);
       
      },
      error: error => {
        alert("Ocurrió un error");
      },
      complete: () => {
        console.info('Agregar plan completa');
        alert("Se agrego correctamente");
      }
    });
    this.form2.reset();
  }
  obtenerPropuesta(): void {
    this._asignacionService.getGestor().subscribe({
      next: data => {
        console.log(data);
        this.lista = data;
      },
      error: error => {
        alert("Ocurrió un error");
      },
      complete: () => {
        console.info('Obtención de propuesta completa');
      }
    });
  }

  obtenerInforme(): void {
    this._informeService.getGestor().subscribe({
      next: data => {
        console.log(data);
        this.listaa = data;
      },
      error: error => {
        alert("Ocurrió un error");
      },
      complete: () => {
        console.info('Obtención de propuesta completa');
      }
    });
  }
}

