import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AsignarPropuestasComponent } from './asignar-propuestas.component';

describe('AsignarPropuestasComponent', () => {
  let component: AsignarPropuestasComponent;
  let fixture: ComponentFixture<AsignarPropuestasComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [AsignarPropuestasComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(AsignarPropuestasComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
