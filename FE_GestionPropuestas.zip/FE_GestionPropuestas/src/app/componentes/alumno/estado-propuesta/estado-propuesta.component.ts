import { HttpClientModule } from '@angular/common/http';
import { Component } from '@angular/core';
import { RouterModule } from '@angular/router';
import { Propuestas } from '../../interfaces/Propuestas';
import { PropuestaService } from '../../../servicios/propuesta.service';

@Component({
  selector: 'app-estado-propuesta',
  standalone: true,
  imports: [HttpClientModule, RouterModule],
  templateUrl: './estado-propuesta.component.html',
  styleUrl: './estado-propuesta.component.css'
})
export class EstadoPropuestaComponent {
  id!:number;
  listadopropuesta: Propuestas[]=[] ;
  constructor( private _propuestaService: PropuestaService) { }

  ngOnInit(): void {
    this.obtenerPropuesta();
  }

  obtenerPropuesta(): void {
    this._propuestaService.getGestor().subscribe({
      next: data => {
        console.log(data);
        this.listadopropuesta = data;
      },
      error: error => {
        alert("Ocurrió un error");
      },
      complete: () => {
        console.info('Obtención de propuesta completa');
      }
    });
  }
}
