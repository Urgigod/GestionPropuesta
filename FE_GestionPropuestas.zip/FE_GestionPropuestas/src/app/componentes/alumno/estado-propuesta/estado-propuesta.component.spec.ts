import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EstadoPropuestaComponent } from './estado-propuesta.component';

describe('EstadoPropuestaComponent', () => {
  let component: EstadoPropuestaComponent;
  let fixture: ComponentFixture<EstadoPropuestaComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [EstadoPropuestaComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(EstadoPropuestaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
