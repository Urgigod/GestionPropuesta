import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { RouterModule, Router } from '@angular/router';
import { PlanificacionService } from '../../../servicios/planificacion.service';
import { SecretariaService } from '../../../servicios/secretaria.service';
import { PlanificacionPeriodo } from '../../interfaces/PlanificacionPeriodo';
import { Secretaria } from '../../interfaces/Secretaria';
import { Gestor } from '../../interfaces/Gestor';
import { ComisionService } from '../../../servicios/comision.service';
import { GestorService } from '../../../servicios/gestor.service';
import { ComisionRevision } from '../../interfaces/ComisionRevision';

@Component({
  selector: 'app-comision-revision',
  standalone: true,
  imports: [ReactiveFormsModule, RouterModule, CommonModule],
  templateUrl: './comision-revision.component.html',
  styleUrl: './comision-revision.component.css'
})
export class ComisionRevisionComponent {
form: FormGroup;
  listaGestor: Gestor[] = [];
  lista: ComisionRevision[] = [];

  constructor(private fb: FormBuilder, 
    private _GestorService: GestorService,
    private _comisionService: ComisionService,
    private router: Router
   
   ) {
    this.form = this.fb.group({
      gestorId: ['', Validators.required],
      fechaCreacion: ['', Validators.required],

    });
  }
  ngOnInit(): void {
    this.consultarSecretarias();
    this.obtenerPropuesta();
  }
  
    consultarSecretarias(): void {
      this._GestorService.getGestor().subscribe({
        next: (data) => {
          console.log('Fetched secretarias:', data); // Log the data to verify it's an array
          this.listaGestor = data;
        },
        error: (error) => {
          console.error('Error fetching secretarias:', error);
        }
      });
    }

  agregarPlanificacion(){
    const plan: ComisionRevision = {
      gestorId: this.form.value.gestorId,
      fechaCreacion: this.form.value.FechaCreacion,
    }

    this._comisionService.addComision(plan).subscribe({
      next: data => {
        console.log(data);
       
      },
      error: error => {
        alert("Ocurrió un error");
      },
      complete: () => {
        console.info('Agregar plan completa');
        alert("Se agrego correctamente");
      }
    });
    this.form.reset();
  }

    obtenerPropuesta(): void {
    this._comisionService.getGestor().subscribe({
      next: data => {
        console.log(data);
        this.lista = data;
      },
      error: error => {
        alert("Ocurrió un error");
      },
      complete: () => {
        console.info('Obtención de propuesta completa');
      }
    });
  }
}
