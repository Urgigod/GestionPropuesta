import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ComisionRevisionComponent } from './comision-revision.component';

describe('ComisionRevisionComponent', () => {
  let component: ComisionRevisionComponent;
  let fixture: ComponentFixture<ComisionRevisionComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ComisionRevisionComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(ComisionRevisionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
