import { Alumno } from "./alumno";

export interface Propuestas{

    propuestasId?: number;
    alumnoId?: number;
    estado :string
    fechaRegistro : Date; 
    alumno? :Alumno;
}