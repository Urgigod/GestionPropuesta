export interface Secretaria{
    secretariaId?: number;
    nombre : string;
}

