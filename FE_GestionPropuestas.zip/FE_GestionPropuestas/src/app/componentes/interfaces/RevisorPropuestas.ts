export interface RevisorPropuestas{
    revisorPropuestasId?: number;
    nombre :string;
}