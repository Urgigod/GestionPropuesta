import { Propuestas } from "./Propuestas";
import { RevisorPropuestas } from "./RevisorPropuestas";



export interface AsignacionPropuestas{
    asignacionPropuestasId?: number;
    propuestasId: number;
    revisorPropuestasId: number;
    fechaAsignacion: Date;
    propuestas?: Propuestas,
    revisorPropuestas?: RevisorPropuestas,
}

