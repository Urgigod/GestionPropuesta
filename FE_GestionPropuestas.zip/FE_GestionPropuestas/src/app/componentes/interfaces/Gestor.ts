export interface Gestor{
   
    gestorId?: number;
    nombre: string;

}