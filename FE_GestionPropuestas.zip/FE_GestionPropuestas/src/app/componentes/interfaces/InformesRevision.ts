import { Gestor } from "./Gestor";
import { Propuestas } from "./Propuestas";

export interface InformesRevision{
    informesRevisionId?: number;
    propuestasId: number;
    gestorId: number;
    observaciones: string;
    fechaGeneracion: Date;
    propuestas?: Propuestas;
    gestor?: Gestor;

}
