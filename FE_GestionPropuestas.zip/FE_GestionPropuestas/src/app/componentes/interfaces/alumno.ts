export interface Alumno{
    alumnoId?: number;
    nombre: string;
}