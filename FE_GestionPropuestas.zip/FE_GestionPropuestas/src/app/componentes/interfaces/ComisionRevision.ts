import { Gestor } from "./Gestor";

export interface ComisionRevision{
    comisionRevisionId?: number;
    gestorId: number;
    fechaCreacion: Date;
    gestor?: Gestor;
}


