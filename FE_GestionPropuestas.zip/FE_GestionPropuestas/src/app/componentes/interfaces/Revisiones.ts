import { Propuestas } from "./Propuestas";
import { RevisorPropuestas } from "./RevisorPropuestas";

export interface Revisiones { 
    
    revisionesId?: number;
    revisorPropuestasId?: number;
    propuestasId?: number;
    observaciones :string
        fechaRevision : Date;
        viabilidad: Boolean;
        necesitaCorrecciones: Boolean;
        revisorPropuestas? :RevisorPropuestas;
        propuestas? :Propuestas;
  }
