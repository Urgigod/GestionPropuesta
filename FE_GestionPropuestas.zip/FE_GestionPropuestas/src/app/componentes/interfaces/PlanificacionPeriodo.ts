import { Secretaria } from "./Secretaria";

export interface PlanificacionPeriodo{
    planificacionId?: number;
    secretariaId?: number;  
    fechaInicio : Date;  
    fechaFin : Date;
    estado : string;
    secretaria? :Secretaria ;
}

