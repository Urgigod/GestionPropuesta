import { ChangeDetectorRef, Component } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { Router, RouterModule } from '@angular/router';
import { PlanificacionService } from '../../../servicios/planificacion.service';
import { PlanificacionPeriodo } from '../../interfaces/PlanificacionPeriodo';
import { Secretaria } from '../../interfaces/Secretaria';
import { SecretariaService } from '../../../servicios/secretaria.service';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-planificacion',
  standalone: true,
  imports: [ReactiveFormsModule, RouterModule, CommonModule],
  templateUrl: './planificacion.component.html',
  styleUrl: './planificacion.component.css'
})
export class PlanificacionComponent {
  form: FormGroup;
  listaSecretaria: Secretaria[] = [];
  listaPlani: PlanificacionPeriodo[] = [];
  archivoSeleccionado: File | null = null;
  propuestas: { nombre: string }[] = [];

  constructor(private fb: FormBuilder, 
    private _planificacionService: PlanificacionService,
    private _secretariaService: SecretariaService,
    private router: Router,
    private cd: ChangeDetectorRef,
   
   ) {
    this.form = this.fb.group({
      secretariaId: ['', Validators.required],
      fechaInicio: ['', Validators.required],
      fechaFin: ['', Validators.required], 
      estado: ['', Validators.required],
    });
  }
  ngOnInit(): void {
    this.consultarSecretarias();
    this.obtenerPropuesta();
    this.propuestas = [
      { nombre: 'Propuesta_Inicial_1.pdf' },
      { nombre: 'Propuesta_Inicial_2.docx' },
      { nombre: 'Propuesta_Inicial_3.pptx' }
    ];
  }
    consultarSecretarias(): void {
      this._secretariaService.getSecretaria().subscribe({
        next: (data) => {
          console.log('Fetched secretarias:', data); // Log the data to verify it's an array
          this.listaSecretaria = data;
        },
        error: (error) => {
          console.error('Error fetching secretarias:', error);
        }
      });
    }

  agregarPlanificacion(){
    const plan: PlanificacionPeriodo = {
      secretariaId: this.form.value.secretariaId,
      fechaInicio: this.form.value.fechaInicio,
      fechaFin: this.form.value.fechaFin,
      estado: this.form.value.estado,
   
    }

    this._planificacionService.addPlanificacion(plan).subscribe({
      next: data => {
        console.log(data);
       
      },
      error: error => {
        alert("Ocurrió un error");
      },
      complete: () => {
        console.info('Agregar plan completa');
        alert("Se agrego correctamente");
      }
    });
    this.form.reset();
  }
  onFileSelected(event: any): void {
    const file = event.target.files[0];
    if (file) {
      console.log('Archivo seleccionado:', file.name);
      this.archivoSeleccionado = file;
    }
  }

  subirPropuesta(): void {
    if (this.archivoSeleccionado) {
      this.propuestas = [...this.propuestas, { nombre: this.archivoSeleccionado.name }]; 
      console.log('Propuestas actualizadas:', this.propuestas);
      this.archivoSeleccionado = null;
      this.cd.detectChanges(); 
    }
  }

  obtenerPropuesta(): void {
    this._planificacionService.getGestor().subscribe({
      next: data => {
        console.log(data);
        this.listaPlani = data;
      },
      error: error => {
        alert("Ocurrió un error");
      },
      complete: () => {
        console.info('Obtención de propuesta completa');
      }
    });
  }
}

