import { RouterModule, Routes } from '@angular/router';
import { PrincipalComponent } from './componentes/principal/principal/principal.component';
import { NgModule } from '@angular/core';
import { PlanificacionComponent } from './componentes/secretaria/planificacion/planificacion.component';
import { ComisionRevisionComponent } from './componentes/gestor/comision-revision/comision-revision.component';
import { AsignarPropuestasComponent } from './componentes/coordinador/asignar-propuestas/asignar-propuestas.component';
import { RevisarPropuestaComponent } from './componentes/revisor/revisar-propuesta/revisar-propuesta.component';
import { EstadoPropuestaComponent } from './componentes/alumno/estado-propuesta/estado-propuesta.component';

export const routes: Routes = [

    { path: '', redirectTo: 'body', pathMatch: 'full' },
    { path: 'body', component: PrincipalComponent },
    { path: 'planificacion', component: PlanificacionComponent },
    { path: 'comision-revision', component: ComisionRevisionComponent },
    { path: 'asignar-propuestas', component: AsignarPropuestasComponent },
    { path: 'revisar-propuesta', component: RevisarPropuestaComponent },
    { path: 'estado-propuesta', component: EstadoPropuestaComponent },
    { path: '**', redirectTo: 'body', pathMatch: 'full' },
];
@NgModule({
    imports: [RouterModule.forRoot(routes)],
    exports: [RouterModule]
  })
  export class AppRoutingModule { }